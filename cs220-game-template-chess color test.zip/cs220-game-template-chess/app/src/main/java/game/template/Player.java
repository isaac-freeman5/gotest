package game.template;

public enum Player
{
    WHITE,
    BLACK
}
